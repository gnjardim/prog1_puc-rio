# Lista 4 - exercício 18

def concatena(s1,s2):
    s3=s2[1:]
    return s1[1:]+s3[-1::-1]

# bloco principal

print(concatena('abcd','mnopq'))
