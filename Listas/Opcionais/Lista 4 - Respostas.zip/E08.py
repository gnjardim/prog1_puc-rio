# Lista 4 - exercício 8

def duracao(dias):
    sem=dias//7
    resto=dias%7
    print(sem,'semanas e',resto,'dias')

# bloco principal

duracao(19)
