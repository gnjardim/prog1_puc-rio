# Lista 4 - exercício 11

import math

def erro_absoluto(valExat,valAprox):
    return math.fabs(valExat - valAprox)

def erro_relativo(valExat,valAprox):
    return erro_absoluto(valExat,valAprox)/valAprox

def erro_percentual(valExat,valAprox):
    return erro_relativo(valExat,valAprox)*100

# bloco principal

print(erro_percentual(101.5,100))
