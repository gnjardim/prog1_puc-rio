# Lista 4 - exercício 3

def soma_dig(n):
    d1=n//10
    d2=n%10
    return d1+d2

def senha(dia,mes,ano):
    aa=ano%100
    return str(soma_dig(dia))+str(soma_dig(mes))+str(soma_dig(aa))
    
# bloco principal

print('A senha do aluno é',senha(27,3,1999))
