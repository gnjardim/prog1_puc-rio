# Lista 4 - exercício 6

def fracao(num,den):
    return str(num)+'/'+str(den)+' = '+str(num/den)

# bloco principal

print(fracao(1,3))
