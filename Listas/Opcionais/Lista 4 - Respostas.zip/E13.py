# Lista 4 - exercício 13

def concatena(s1,s2):
    return s1[5:]+s2[0:len(s2)-10]

# bloco principal

print(concatena('12345Rio de Janeiro - ','Brasil0123456789'))
