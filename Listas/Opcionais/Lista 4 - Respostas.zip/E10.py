# Lista 4 - exercício 10

import math

def volumeCaixa(a,b,h):
    return a*b*h

def volumeCilindro(r,h):
    return math.pi*h*(r**2)

def volumeObjeto(a,b,h,r):
    return volumeCaixa(a,b,h) - volumeCilindro(r,h)

# bloco principal

print(volumeObjeto(5,5,5,2))
