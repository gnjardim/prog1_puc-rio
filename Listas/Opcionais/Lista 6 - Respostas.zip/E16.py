# Lista 6 - exercício 16

def calculaMargemLucro(gastoMat,custoTot,custoTotMo):
    r=gastoMat/custoTotMo

    if r < 0.5:
        return 0.1*custoTotMo
    elif r > 1.5:
        return 0.05*gastoMat
    else:
        return 0.08*custoTot

gastoMat=float(input('Gasto com material?'))
durConstr=float(input('Duração da obra?'))
custoMo=float(input('Custo da hora de trabalho?'))
areaConstr=float(input('Área construída'))

if areaConstr/durConstr < 0.035:
    custoMo*=1.3

custoTot=gastoMat+custoMo*durConstr
margemLucro=calculaMargemLucro(gastoMat,custoTot,custoMo*durConstr)
precoVenda=custoTot+margemLucro
print('O preço de venda do m2 é R$ %.2f'%(precoVenda/areaConstr))
