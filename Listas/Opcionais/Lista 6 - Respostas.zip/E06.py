# Lista 6 - exercício 6

def calculaImc(peso,altura):
    return peso/altura**2

peso=float(input('Peso?'))
altura=float(input('Altura?'))
imc=calculaImc(peso,altura)
print('IMC=%.2f'%imc)

if imc < 18.5:
    print('Cuidado! Você está abaixo do peso')
