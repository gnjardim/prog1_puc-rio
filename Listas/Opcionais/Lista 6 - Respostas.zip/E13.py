# Lista 6 - exercício 13

def calcDesconto(valor,perc):
    return valor*(perc/100)

qtd=int(input('Quantidade?'))
precUnit=float(input('Preço unitário?'))

vlCompr=qtd*precUnit

if qtd > 15:
    vlCompr-=calcDesconto(vlCompr,10) #  vlCompr=vlCompr-calcDesconto(vlCompr,10)
if vlCompr > 100:
    vlCompr-=calcDesconto(vlCompr,20) #  vlCompr=vlCompr-calcDesconto(vlCompr,10)
    
print('Total a pagar: %.2f'%vlCompr)
