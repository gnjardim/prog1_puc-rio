# Lista 6 - exercício 21

def trataHorExcedente(qtdHorExced,valHora):
    valHorExced=valHora*0.5
    valExced=qtdHorExced*valHorExced
    if qtdHorExced > 30:
        valExced*=1.1
    return valExced
        
numHoras=int(input('Número de horas trabalhadas?'))
valHora=float(input('Valor da hora trabalhada?'))

valExced=0

if numHoras > 50:
    valExced=trataHorExcedente(numHoras-50,valHora)

print('Montante a receber: R$ %.2f'%(numHoras*valHora+valExced))


