# Lista 6 - exercício 18

def diaDaSemana(dia,mes,ano):
    a=ano-1900
    print('a=',a)
    b=a//4
    if ano%4 == 0 and (mes == 1 or (mes==2 and dia <= 29)):
        b=b-1
    print('b=',b)
    if mes == 1 or mes == 10:
        c=0
    elif mes == 5:
        c=1
    elif mes == 8:
        c=2
    elif mes == 2 or mes == 3 or mes == 11:
        c=3
    elif mes == 6:
        c=4
    elif mes == 9 or mes == 12:
        c=5
    else:
        c=6
    print('c=',c)    
    d=dia-1
    print('d=',d)
    return (a+b+c+d)%7

dia=int(input('Dia?'))
mes=int(input('Mês?'))
ano=int(input('Ano?'))

ds=diaDaSemana(dia,mes,ano)

if ds==1 or ds==3:
    print('Hoje haverá aula de INF1025')
    if ds==3:
        print('Hoje haverá teste')

