﻿#
# Solução do exercicio 3 da lista 8
#
def calculaNumAnos(valInicial,txJurosAnual):
    tx=1+txJurosAnual/100
    i=0
    valCor=valInicial

    while valCor < 2*valInicial:
        print(valCor,valInicial)
        valCor*=tx
        i+=1

    return i

valInicial=float(input('Valor inicial?'))
txJurosAnual=float(input('Taxa de juros anual?'))
print('O capital irá dobrar em %d anos'%calculaNumAnos(valInicial,txJurosAnual))

