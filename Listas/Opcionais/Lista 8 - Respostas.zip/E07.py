#
# Solução do exercicio 7 da lista 8
#
i=0
prim=0
dentroInt=0
somaDentroInt=0
maiorForaInt=0
t=int(input('total de numeros: '))
while(i<t):
    n=int(input('numero: '))
    i+=1
    if 1<=n<=15:
        print(n,'esta dentro do intervalo')
        dentroInt+=1
        somaDentroInt+=n
    else:
        if prim==0:
            prim=1
            menorForaInt=n
        print(n,'esta fora do intervalo')
        if n>maiorForaInt:
            maiorForaInt=n
        if n<menorForaInt:
            menorForaInt=n
print(dentroInt,'valores dentro do intervalo','soma=',somaDentroInt,'media=',somaDentroInt/dentroInt)
print(t-dentroInt,'valores fora do intervalo','maior=',maiorForaInt,'menor=',menorForaInt)

        
    
