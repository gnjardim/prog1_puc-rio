#
# Solução do exercicio 37 da lista 8
#
def comparaHorarios (previsto, efetivo):
    horaPrevisto = previsto[0:2]
    minutoPrevisto =previsto[3:]
    horaEfetivo = efetivo[0:2]
    minutoEfetivo =  efetivo[3:]
    minutosPrevisto = int(horaPrevisto)*60+int(minutoPrevisto)
    minutosEfetivo = int(horaEfetivo)*60+int(minutoEfetivo)
    diferencaHorarios = minutosPrevisto - minutosEfetivo
    if (minutosPrevisto == minutosEfetivo):
        print ("Vôo no horário")
    elif (minutosPrevisto > minutosEfetivo):
        print ("Vôo adiantado")
    else:
        print ("Vôo atrasado")
    return diferencaHorarios

def processaAeroporto (numeroVoos):
    i = 0
    totalNoHorário = 0
    totalAtrasados = 0
    tempoAtrasos = 0 
    while (i < numeroVoos):
        numeroDoVoo = input ('\nDigite número do vôo : ')
        horarioPrevisto = input ('Digite horário previsto de chegada hh:mm : ')
        horarioEfetivo = input ('Digite horário efetivo de chegada hh:mm : ')
        diferenca = comparaHorarios (horarioPrevisto, horarioEfetivo)
        if diferenca == 0:
            totalNoHorário+=1
        elif diferenca < 0:
            totalAtrasados+=1
            tempoAtrasos+= (-1)*diferenca
        i+=1

    print ('\nPercentual vôos no horário: %d%%'%(totalNoHorário*100/numeroVoos))
    print ('Qtd vôos em atraso: %d'%totalAtrasados)
    if (totalAtrasados > 0):
        print ('Tempo médio de atraso: %d minutos'%(tempoAtrasos/totalAtrasados))
    return totalAtrasados

j=0
maiorQtdAtraso = -1
nomeAeroportoMaiorQtdAtraso = ''
while (j<10):
    nomeAeroporto = input ('\n\nDigite nome Aeroporto : ')
    numVoos = int(input ('\nDigite número de vôos : '))    
    qtdAtraso = processaAeroporto (numVoos)
    if qtdAtraso > maiorQtdAtraso:
        nomeAeroportoMaiorQtdAtraso = nomeAeroporto
        maiorQtdAtraso = qtdAtraso
    j+=1
print ('\n\nAeroporto com maior qtd de voos em atraso : ',nomeAeroportoMaiorQtdAtraso)
