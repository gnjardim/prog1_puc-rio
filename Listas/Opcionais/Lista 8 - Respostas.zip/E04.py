#
# Solução do exercicio 4 da lista 8
#
def qtd_anos (alt1, alt2):
    cm1 = int (input ('Quantos cm Huguinho cresceu no ano? '))
    cm2 = int (input ('Quantos cm Luizinho cresceu no ano? '))
    anos = 1
    while (alt1 + cm1 < alt2 + cm2) and (cm1 + cm2 != 0):
        alt1 += cm1
        alt2 += cm2
        anos += 1
        cm1 = int (input ('Quantos cm Huguinho cresceu no ano? '))
        cm2 = int (input ('Quantos cm Luizinho cresceu no ano? '))
    return anos

        
