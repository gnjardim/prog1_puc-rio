#
# Solução do exercicio 20 da lista 8
#
def exibeMontante(valorInicial, taxaInicial):
    mes = 1
    taxa = taxaInicial
    montante = valorInicial
    if montante % 13 == 0 and montante < 2 * valorInicial:
        montante += 1000.0
        print('Premio de R$1000.00 incorporado')
    while montante < 2 * valorInicial:
        print('mes: %d taxa: %.4f montante: %.2f'%(mes,taxa,montante))
        mes += 1
        if mes % 3 == 0:
            taxa *= 1.002
            if mes % 12 == 0:
                taxa *= 1.02
        montante *= taxa
        if montante % 13 == 0 and montante < 2 * valorInicial:
            montante += 1000.0
            print('Premio de R$1000.00 incorporado')
    print('mes: %d taxa: %.4f montante: %.2f'%(mes,taxa,montante))
    print('o valor duplicou em %d meses'%mes)

valor = float(input('Qual o montante a ser aplicado?'))
taxa = float(input('Qual a taxa a ser aplicada?'))
exibeMontante(valor,taxa)
        
