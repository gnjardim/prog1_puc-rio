#
# Solução do exercicio 38 da lista 8
#
def maior_18 (idade):
    return idade >= 18

def determina_vale(idade,livrosTecnicos,livrosNaoTecnicos):
    if not maior_18 (idade):
        return 0.0
    totalLivros = livrosTecnicos+livrosNaoTecnicos
    if totalLivros < 3:
        return 0.0
    if (totalLivros == 3) and (livrosTecnicos == 0 or livrosNaoTecnicos == 0):
        return 100.0
    if totalLivros == 3:
        return 150.0
    return 200.0


i=0
while (i < 100):
    idade = int(input('\nDigite idade : '))
    sexo = input('Digite sexo (M ou F) : ')
    tecnicos = int(input('Digite quantidade livros técnicos : '))
    naoTecnicos = int(input('Digite quantidade livros não técnicos : '))
    print ('Valor do vale : R$ %.2f'%determina_vale(idade,tecnicos,naoTecnicos))
    i+=1

