#
# Solução do exercicio 24 da lista 8
#
def calcula_tamanho( cod):
    print('Dimensões do brinquedo %d'%cod)
    A=float(input("\tAltura? "))
    B=float(input("\tLargura? "))
    C=float(input("\tComprimento? "))
    diagonal = ((A*A)+(B*B)+(C*C))**0.5
    print(diagonal)
    return diagonal;


qt10=0
qt15=0
qt20=0
qt25=0
cod=int(input("Digite o código do brinquedo ou 0 para finalizar: "))
while cod >= 0:
    diagonal=calcula_tamanho(cod)
    if diagonal <= 10:
            diamEsfera = 10
            qt10+=1            
    elif diagonal <=15:
            diamEsfera = 15;
            qt15+=1
    elif diagonal <=20:
            diamEsfera = 20;
            qt20+=1
    else:
            diamEsfera = 25;
            qt20+=1
    print("Brinquedo: %d - Diâmetro: %d"%(cod,diamEsfera))
    cod=int(input("Digite o código do próximo brinquedo ou 0 para finalizar: "))
        
print("Quantidade de Embalagens")
print("\t10cm: %d"%qt10)
print("\t15cm: %d"%qt15)
print("\t20cm: %d"%qt20)
print("\t25cm: %d"%qt25)
    
'''
25.

(I)  A  vigilância  sanitária  do  reino  Tã

oT

ãoPróximo  autua  os  supermercados  visitados  conforme  o  número  de  

produtos  fora  da  validade.  Em  toda  esta  questão,  considere  que  cada  data

  é  representada  por  três  números  

inteiros,  correspondentes  ao  dia,  mês  e  ano,  respectivamente.    

a)

Escreva  uma  funçã

o  

produto_vencido,  que  recebe  a  data  da  visita  e  a  data  de  validade  do  produ

to  e  

retorna  True,  caso  o  produto  esteja  fora  da  validade,  ou  False,  caso  contr

ário.    

b)

Escreva  uma  função  calcula_multa,  que  recebe  a  quantidade  de  produtos  conferi

dos  e  a  quantidade  

de  produtos  fora  da  validade,  e  retorna  o  valor  da  multa,  de  acordo  co

m  as  seguintes    regras:    



0,  caso  nenhum  produto  conferido  esteja  fora  da  validade;    



100,  caso  até  10%  dos  produtos  conferidos  estejam  fora  da  validade;    



10.000,  caso  mais  de  10%  e  até  30%  dos  produtos  conferidos  estejam  fora  d

a  validade;  e    



100.000,  caso  mais  de  30%  dos  produtos  conferidos  estejam  fora  da  validade.

c)

Fa

ça  um  programa  que  inicialmente  leia  a  data  da  visita  ao  supermercado.  Em  segu

ida,  para  cada  

produto  conferido,  leia  o  nome  do  produto  e  a  data  do  seu  vencimento,

  mostrando  para  cada  

produto  se  ele  está  ou  não  na  validade.    

A  entrada  de  dados  é  finalizada  quando  for  digitado  um  nome  de  produto

  vazio  ('').  Seu  programa  deverá  então  

calcular  e  exibir  o  valor  da  multa,  caso  haja,  ou  informar  que  o  supermercado

  está  isento  de  multas.
  '''
