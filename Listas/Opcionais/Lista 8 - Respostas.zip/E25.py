#
# Solução do exercicio 25 da lista 8
#
def montaData(d,m,a):
    return str(a)+str(m) + str(d)
def produto_vencido(dvis, mvis, avis, dval, mval, aval):
    return montaData(dvis,mvis,avis)>montaData(dval,mval,aval)

def calcula_multa(numprodutos,numvencidos):
    if numvencidos == 0:
        return 0;
    razao = numvencidos / numprodutos;
    if razao <= 0.1:
        multa= 100;
    elif razao <= 0.3:
        multa =10000;
    else:
        multa= 100000;
    return multa
numvencidos=0
numprodutos=0
dtVis=input("Digite a data da visita (dd/mm/aaaa): ")
dvis = int(dtVis[:2])
mvis = int(dtVis[3:5])
avis = int(dtVis[6:])
nome=input("Digite o produto ou tecle enter para finalizar: ");
while nome:
    dtVal=input("Digite a data da validade (dd/mm/aaaa) de %s: "%nome)
    dval = int(dtVal[:2])
    mval = int(dtVal[3:5])
    aval = int(dtVal[6:])
    numprodutos+=1
    print(nome,end=' ')
    if produto_vencido(dvis, mvis, avis, dval, mval, aval):
        numvencidos +=1
        print('está fora da validade')
    else:
        print('está na validade')
    nome=input("Digite o próximo produto ou tecle enter para finalizar: ");
    
multa = calcula_multa(numprodutos, numvencidos);
if multa == 0:
    print("Isento de multa.");
else:
    print("Multa de R$ %.2f"% multa);
