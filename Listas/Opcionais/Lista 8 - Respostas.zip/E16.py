#
# Solução do exercicio 16 da lista 8
#
def eh_primo(n):
    divisor = 2
    limite = n**(1/2) # só precisa testar até a raiz de n
    
    while divisor <= limite:
        if n % divisor == 0:
            return False
        divisor += 1

    return True

def mostra_primos(a,b):
    candidato = a
    while candidato <= b:
        if eh_primo(candidato):
            print(candidato)
        candidato += 1

# Teste da questão 16
mostra_primos(1,30)
