#
# Solução do exercicio 18 da lista 8
#
def totalCompras(n):
    somaPrecos = 0
    maisCaro = 0
    cont = 0
    while cont < n:
        preco = float(input("Qual o preço do produto?"))
        if preco > maisCaro:
            maisCaro = preco
        somaPrecos += preco
        cont += 1
    print('Seu produto mais caro custou: %.2f'%maisCaro)
    return somaPrecos

contaMais200 = 0
totalClientes = 0
totalComprado = 0
maiorTotalComprado = 0
nome = input('Qual seu nome?')
while nome != '':
    totalClientes += 1
    n = int(input("Quantos produtos foram comprados?"))
    valorTotal = totalCompras(n)
    print('D - À vista em dinheiro ou cheque: 1 x %.2f'%(0.80 * valorTotal))
    print('C - À vista com cartão de crédito: 1 x %.2f'%(0.85 * valorTotal))
    print('P - Parcelado no cartão: 2 x %.2f'%(valorTotal/2))
    print('J - Parcelado no cartão: 3 x %.2f'%(1.1*valorTotal/3))
    totalComprado += valorTotal
    if valorTotal > 200:
        contaMais200 += 1
    if valorTotal > maiorTotalComprado:
        maiorTotalCompra = valorTotal
        nomeMaiorTotal = nome
    nome = input('Qual seu nome?')
print('%d clientes compraram mais de R$ 200.00.'%contaMais200)
print('Valor medio por cliente: R$%.2f'%(totalComprado/totalClientes))
print('O cliente %s foi o que mais comprou.'%nomeMaiorTotal)
