﻿#
# Solução do exercicio 23 da lista 8
#
def diaria(quarto):
    andar = quarto // 100
    if andar == 4:
        return 450
    elif andar == 3:
        return 300
    elif andar == 2:
        return 180
    else:
        return 90

def despesa(quarto,diarias,consumo):
    d = diaria(quarto)
    sub_diarias = diarias * d
    taxas = .06*sub_diarias + .10*consumo
    sub_total =  sub_diarias + consumo
    total_geral = sub_total + taxas
    recibo = '\n\n   RECIBO DE DESPESA' + \
          '\n\tQuarto: %d' + \
          '\n\tDiarias: %d\n\tValor Unit. da Diaria: %d' + \
          '\n\tTotal das Diarias: %d\n\tConsumo: %.2f' + \
          '\n\tSub-total: %.2f\n\tTaxas: %.2f\n\t**** TOTAL: %.2f ****'
    print( recibo %   \
          (quarto,
           diarias, d, sub_diarias,
           consumo,
           sub_total, taxas,
           total_geral))
    return

def hospedes():
    quarto = int(input('Número do quarto (0 para encerrar):'))
    while quarto != 0:
        diarias = int(input('Número de diárias:'))
        consumo = float(input('Valor do consumo interno:'))
        despesa(quarto, diarias, consumo)
        quarto = int(input('Número do quarto (0 para encerrar):'))
    print('\n...Bye')

hospedes()   
