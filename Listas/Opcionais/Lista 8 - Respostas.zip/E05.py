#
# Solução do exercicio 5 da lista 8
#
# Inicializacao das variaveis
#
somamenores18 = qtdmenores18 = 0
somamaiores20 = qtdmaiores20 = 0
maisvelha = 0
cont = 0
while cont < 6:
#
# Leitura da idade e teste da faixa etaria
#
    idade = int (input ('Digite a sua idade: '))
    if idade < 18:
        qtdmenores18 += 1
        somamenores18 += idade
    else:
        if idade > 20:
            qtdmaiores20 += 1
#
# Teste da maior idade 
#
    if idade > maisvelha:
        maisvelha = idade
    cont += 1
#
# Impressao dos resultados
#
print ('Qtd. de pessoas menores de idade: %d\n' %qtdmenores18)
print ('Idade média de pessoas menores de idade: %.1f\n' %(somamenores18 / qtdmenores18))
print ('Idade da pessoa mais velha: %d\n' %maisvelha)
print ('Percentual de pessoas com mais de 20 anos: %.1f%%\n' %((qtdmaiores20 / cont) * 100))
