#
# Solução do exercicio 6 da lista 8
#
for i in range(5):
    nPessoas=0
    maiores=0
    idadeMaisVelho=0
    nomeMaisVelho=''
    idadeMenor11=1
    while True:
        nome=input('nome participante: ')
        if nome=='':
            break
        idade=int(input('idade participante: '))
        nPessoas+=1
        if idade>=18:
            maiores+=1
        if idade>idadeMaisVelho:
            idadeMaisVelho=idade
            nomeMaisVelho=nome
        if idade<11:
            idadeMenor11=0
    if nPessoas>=5 and maiores/nPessoas>=0.5 and idadeMenor11==1:
        print('O grupo',i+1,'pode participar da excursão')
    else:
        print('O grupo',i+1,'nao pode participar da excursão')
    print('Lider:',nomeMaisVelho,'\n')
    
    
