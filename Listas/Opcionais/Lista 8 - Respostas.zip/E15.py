#
# Solução do exercicio 15 da lista 8
#
def eh_primo(n):
    divisor = 2
    limite = n**(1/2) # só precisa testar até a raiz de n
    
    while divisor <= limite:
        if n % divisor == 0:
            return False
        divisor += 1

    return True

# Teste da questão 15
print(eh_primo(6))
