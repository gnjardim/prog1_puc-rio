﻿#
# Solução do exercicio 22 da lista 8
#
import random

def risco(m,a,c):
    return random.randint(0,10)

def resultado(m,a,c,r):
    return m*(1 + (a/100)*r/100 + (c/100)*(10-r)/100)

def tabela_retorno(m):
    print('\n\nAções\t  CDI\tRisco\tResultado')
    a=100
    r_min = 11
    res_max = -1
    while a>=0:
        c = 100 - a
        r = risco(m,a,c)
        res = resultado(m,a,c,r)
        if r < r_min:
            r_min = r
            res_max = res
        elif r == r_min and res > res_max:
            res_max = res                
        print('%4d\t%5d\t%3d\t%.2f'%(a,c,r,res))
        a = a - 10
    return res_max

def tabelas_de_retorno():
    m = float(input('\nMontante (-1 para encerrar):'))
    while m != -1:
        best = tabela_retorno(m)
        print('Melhor resultado para o menor risco: %f' % best)     
        m = float(input('\nMontante (-1 para encerrar):'))
    print('\n\n\n...Bye')
    return

tabelas_de_retorno()
