﻿#
# Solução do exercicio 2 da lista 8
#
valBasico=float(input('Valor básico?'))
i=1
while i <= 12:
    print('Valor da parcela da anuidade do mês %02d: R$ %.2f'%(i,valBasico))
    valBasico*=1.05
    i+=1
