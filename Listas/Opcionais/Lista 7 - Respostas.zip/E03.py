def algMenores(n1,n2):
    if n1 < 10:
        if n1 < n2:
            return True
        else:
            return False

    r1=n1%10
    r2=n2%10

    if r1 < r2:
        return True and algMenores(n1//10,n2//10)
    else:
        return False

print(algMenores(1234,2436))
        
