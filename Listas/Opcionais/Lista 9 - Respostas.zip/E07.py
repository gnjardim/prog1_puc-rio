# Lista 9 - exercício 7

def geraLista(lstJogos):
    lstFaltas=[]
    for e in lstJogos:
        s1=e[0]
        s2=e[1]
        if [s1,0] not in lstFaltas:
            lstFaltas+=[[s1,0]]
        if [s2,0] not in lstFaltas:
            lstFaltas+=[[s2,0]]

    return lstFaltas

def busca(lstFaltas,selecao):
    for i in range(len(lstFaltas)):
        if lstFaltas[i][0]==selecao:
            return i
    return -1

def contabilizaFaltas(lstJogos,lstFaltas):
    for i in range(len(lstJogos)):
        r=busca(lstFaltas,lstJogos[i][0])
        lstFaltas[r][1]+=lstJogos[i][2][0]
        r=busca(lstFaltas,lstJogos[i][1])
        lstFaltas[r][1]+=lstJogos[i][2][1]

    return lstFaltas
        

lstJogos=[['Brasil', 'Italia', [10, 9]], ['Brasil','Espanha', [5, 7]], ['Italia', 'Espanha', [7,8]]]
lstFaltas=geraLista(lstJogos)
contabilizaFaltas(lstJogos,lstFaltas)

men=0
mai=0
tot=lstFaltas[0][1]
for i in range(1,len(lstFaltas)):
    if lstFaltas[i][1] > lstFaltas[mai][1]:
        mai=i
    elif lstFaltas[i][1] < lstFaltas[men][1]:
        men=i
    tot+=lstFaltas[i][1]

print('Total de faltas marcadas no campeonato:',tot)
print('A seleção',lstFaltas[men][0],'cometeu o menor número de faltas')
print('A seleção',lstFaltas[mai][0],'cometeu o maior número de faltas')
