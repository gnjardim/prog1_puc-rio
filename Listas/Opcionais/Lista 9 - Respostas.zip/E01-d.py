# Lista 9 - exercício 1-D

def media(lst):
    s=0
    for e in lst:
        s+=e

    return s/len(lst)

lst=[6,8,10,7,9]
print(media(lst))
            
