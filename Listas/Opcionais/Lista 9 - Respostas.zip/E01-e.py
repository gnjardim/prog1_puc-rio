# Lista 9 - exercício 1-E

def media(lst):
    s=0
    for e in lst:
        s+=e

    print(s/len(lst))
    return s/len(lst)

def valMaisProx(lst):
    med=media(lst)
    m=lst[0]
    mDif=abs(m-med)
    for i in range(1,len(lst)):
        dif=abs(med-lst[i])
        if dif < mDif:
            mDif=dif
            m=lst[i]

    return m

lst=[6]
print(valMaisProx(lst))
lst=[-1,2,5,3.5]
print(valMaisProx(lst))            
