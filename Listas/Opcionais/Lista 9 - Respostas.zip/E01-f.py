# Lista 9 - exercício 1-F

def somaNegativo(lst):
    s=0
    for e in lst:
        if e < 0:
            s+=e

    return s

lst=[6,8,-10,7,-9,3,2,1,5.6]
print(somaNegativo(lst))
            
