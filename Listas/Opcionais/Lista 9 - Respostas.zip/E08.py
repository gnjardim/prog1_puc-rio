# Lista 9 - exercício 8

lista=[2.5, 7.5, 10.0, 4.0, 8.0, 4.0, 5.5, 1.0, 11.0]
soma=0

for e in lista:
    soma+=e

media=soma/len(lista)

maisProx=lista[0] # assume que o 1o elemento é o mais próximo da média
menorDif=abs(lista[0]-media) # assume que o 1o elemento é o mais próximo da média

for i in range(1,len(lista)): # percorre a lista a partir do 2o elemento (1)
    if abs(lista[i]-media)<menorDif:
        maisProx=lista[i]
        menorDif=abs(lista[i]-media)
    
print("Média: ",media)
print("O valor mais próximo da média é",maisProx)
