# Lista 9 - exercício 1-A

def maior(lst):
    m=lst[0]
    for i in range(1,len(lst)):
        if lst[i]>m:
            m=lst[i]

    return m


lst=[12,45.8,5,7.8,9,1.1,23]
print(maior(lst))
            
