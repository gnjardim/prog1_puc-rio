# Lista 9 - exercício 1-G

def qtdVizinhos(lst):
    qtd=0
    for i in range(len(lst)-1):
        if lst[i]==lst[i+1]:
            qtd+=1

    return qtd

lst=[2,2,2,1,2,1,1]
print(qtdVizinhos(lst))


            
