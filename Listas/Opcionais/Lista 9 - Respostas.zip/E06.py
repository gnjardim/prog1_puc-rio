# Lista 9 - exercício 6

def traduzir(lSecreta):
    alfa=" abcdefghijklmnopqrstuvwxyz"
    msg=""

    for e in lSecreta:
        msg=msg+alfa[e]

    return msg

lSecreta=[2,15,13,0,4,9,1] 
print(traduzir(lSecreta))
