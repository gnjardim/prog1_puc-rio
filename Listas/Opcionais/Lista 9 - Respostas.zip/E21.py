# Lista 9 - exercício 21

def buscaPrato(LPratos,prato):
    for i in range(len(LPratos)):
        if LPratos[i][0]==prato:
            return i
    return

def buscaIngrediente(LIngr,ingr):
    for i in range(len(LIngr)):
        if LIngr[i][0]==ingr:
            return i
    return

def custoPrato(LComp,LIngr):
    soma=0.0
    for el in LComp:
        res=buscaIngrediente(LIngr, el[0])
        ci=el[1]*LIngr[res][2]
        soma=soma + ci
    return soma
        
LIngr=[['Arroz',100,5.00],['Carne',100,16.00],\
         ['Batata Inglesa',250,3.50],['Cenoura',100,3.00],\
         ['Queijo Minas',150,12.00]]
LPratos=[['Batata Recheada',[['Batata Inglesa',3],\
        ['Carne',2]]],['Muito Escondidinho',[['Batata Inglesa',3],['Queijo Minas',1],\
        ['Cenoura',1]]],['Pastelão de Vento',[['Batata Inglesa',4],\
        ['Carne',1]]]]
LConsumo=[['Muito Escondidinho',12],['Pastelão de Vento',30]]

mCusto=0.0
mNome=''
for i in range(len(LPratos)):
    custo=custoPrato(LPratos[i][1],LIngr)
    if custo > mCusto:
        mCusto=custo
        mNome=LPratos[i][0]

print('Prato mais caro: %s\nCusto: %.2f'%(mNome,mCusto))

# A lista que representa o somatório das quantidade de ingredientes (vetSoma)
# que terão de ser comprados para fazer o cardápio da semana tem de ter
# tantos elementos quantos forem os ingredientes (len(LIngr)).
# Essa lista tem de ser inicialmente "zerada".
vetSoma=[0]*len(LIngr)

for cons in LConsumo:
    r1=buscaPrato(LPratos,cons[0])
    for ingr in LPratos[r1][1]:
        r2=buscaIngrediente(LIngr,ingr[0])
        #soma+=pesoIngrediente*numPorçoesIngrediente*numPratosSemana
        vetSoma[r2]+=ingr[1]*LIngr[r2][1]*cons[1]

print('\n\n--------- LISTA DE COMPRAS DA SEMANA ----------\n')
for i in range(len(LIngr)):
    if vetSoma[i] > 0:
        print('%-30s\t%dg'%(LIngr[i][0],vetSoma[i]))       

        
        
        
    





