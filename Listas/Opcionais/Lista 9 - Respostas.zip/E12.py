# Lista 9 - exercício 12

def buscaListaA(lNumeros,num):
    if len(lNumeros)==0:
        return -2
    if num in lNumeros:
        return 0
    else:
        return -1

def buscaListaB(lNumeros,num):
    if len(lNumeros)==0:
        return -2

    for i in range(len(lNumeros)):
        if type(lNumeros[i])==int:
            if lNumeros[i]==num:
                return 0
        else:
            for j in range(len(lNumeros[i])):
                if lNumeros[i][j]==num:
                    return 0        
    return -1    


lNumeros=[1111,2222,3333,5555,6666]
print(buscaListaA(lNumeros,6666))
print(buscaListaA(lNumeros,4444))
print(buscaListaA([],44444))
lNumeros=[1111,2222,[3333,5555,6666],7777,9999]
print(buscaListaB(lNumeros,5555))
