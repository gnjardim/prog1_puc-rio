# Lista 9 - exercício 14

def megaSena(lApostas,resultado):
    venc=[]
    for el in lApostas:
        apost=el[1]
        if apost==resultado:
            venc.append(el[0])

    return venc
  


lApostas=[[1111,[10,20,30,40,50,60]],[2222,[11,12,13,14,15,16]],[3333,[10,20,30,40,50,60]]]
resultado=[10,20,30,40,50,60]                        
print(megaSena(lApostas,resultado))
