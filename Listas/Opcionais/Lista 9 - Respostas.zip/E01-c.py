# Lista 9 - exercício 1-C

def numOcor(lst):
    s=0
    for e in lst:
        if e==lst[0]:
            s+=1

    return s

lst=[1,6,6,6,1]
print(numOcor(lst))
            
