# Lista 9 - exercício 1-B

def soma(lst):
    s=0
    for e in lst:
        s+=e

    return s

# Bloco principal

lst=[]
print(soma(lst))
lst=[]
print(soma([0,4.2,0,3.8,-1,2.5,0,0.5]))
            
