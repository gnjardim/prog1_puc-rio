# Lista 5 - exercício 8

tam=float(input('Tamanho do arquivo em megabits?'))
vel=float(input('Velocidade do link em megabits por segundo?'))

ts=tam/vel
tm=ts/60

print('O upload será feito em aproximadamente %.2f minutos'%tm)

h=ts//3600
m=(ts%3600)//60
s=(ts%3600)%60

print('O tempo aproximado de upload é %02d:%02d:%02d'%(h,m,s))
