# Lista 5 - exercício 4

import math

def volumeCaixa(larg,compr,altura):
    return larg*compr*altura

def volumeCilindro(raio,altura):
    return altura*math.pi*raio**2

larg=float(input('Lagura da caixa?'))
compr=float(input('Comprimento da caixa?'))
altura=float(input('Altura da caixa?'))
raio=float(input('Raio do círculo?'))

vCaixa=volumeCaixa(larg,compr,altura)
vCil=volumeCilindro(raio,altura)

print('O volume do sólido é %.2f m3'%(vCaixa-vCil))
