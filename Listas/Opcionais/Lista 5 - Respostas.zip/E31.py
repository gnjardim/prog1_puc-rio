# Lista 5 - exercício 31

prGal=float(input('Preço, em US$, do galão de gasolina nos EUA?'))
prDolar=float(input('Preço do US$?'))

prLitro=prGal/3.7854

print('O preço de um litro de gasolina nos EUA é R$%.2f'%(prLitro*prDolar))
