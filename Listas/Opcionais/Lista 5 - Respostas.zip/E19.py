# Lista 5 - exercício 19

ent=input('Hora de entrada? hh:mm')
sai=input('Hora de saída? hh:mm')

he=int(ent[0:2])
me=int(ent[3:])
hs=int(sai[0:2])
ms=int(sai[3:])

tPerm=(hs*60+ms)-(he*60+me)

print('O tempo de permanência do aluno foi de %02d:%02d'%(tPerm//60,tPerm%60))
