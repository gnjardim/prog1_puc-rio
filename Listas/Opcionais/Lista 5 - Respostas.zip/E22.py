# Lista 5 - exercício 22

dt=input('Digite uma data no formato dd/mm/aaaa')
dtInv=dt[3:5]+'/'+dt[0:2]+'/'+dt[6:]
print('Data invertida:',dtInv)
