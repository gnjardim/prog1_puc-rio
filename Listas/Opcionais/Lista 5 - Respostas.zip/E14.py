# Lista 5 - exercício 14

mat=int(input('Matrícula do aluno?'))

ano=mat//10000
r=mat%10000
sem=r//1000

print('O aluno ingressou no %do. semestre de 20%02d'%(sem,ano))
