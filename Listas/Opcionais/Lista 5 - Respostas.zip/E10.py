# Lista 5 - exercício 10

def area_Mostellerl(altura, peso):
    return ((peso*altura)**0.5)/60

def area_Haycock(altura, peso):
    return peso**0.5378 * altura**0.3964 * 0.024265

altura=float(input('Altura em cm?'))
peso=float(input('Peso em kg?'))

aMost=area_Mostellerl(altura, peso)
aHayc=area_Haycock(altura, peso)

print('Área corporal segundo a fórmula de Mosteller é %.4f'%aMost)
print('Área corporal segundo a fórmula de Haycock é %.4f'%aHayc)
print('A diferença entre as duas medidas é %.4f'%(abs(aHayc-aMost)))
