# Lista 5 - exercício 24

import random

def geraString(nome,sNome):
    l1=len(nome)
    l2=len(sNome)
    if l1 < l2:
        limite=l1
    else:
        limite=l2
        
    # o procedimento acima não faz parte do enunciado, mas evita
    # que o número sorteado seja maior do que o comprimento do nome
    # ou do sobrenome
    
    n=random.randint(1,limite)
    return nome[0:n]+sNome[0:n]+'*'+nome[n:]+'&'+sNome[n:]
    
nome=input('Nome?')
sNome=input('Sobrenome?')
print(geraString(nome,sNome))

