# Lista 5 - exercício 17

nv=int(input('Número de vitórias?'))
ne=int(input('Número de empates?'))
nd=int(input('Número de derrotas?'))

print('O time tem %d pontos no Campeonato Brasileiro'%(nv*3+ne))
