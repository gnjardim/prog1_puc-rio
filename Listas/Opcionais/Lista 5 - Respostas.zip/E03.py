# Lista 5 - exercício 3

import math

def areaRetangulo(larg,compr):
    return larg*compr

def areaCirculo(raio):
    return math.pi*raio**2

larg=float(input('Lagura da caixa?'))
compr=float(input('Comprimento da caixa?'))
altura=float(input('Altura da caixa?'))
raio=float(input('Raio do círculo?'))

areaLateral=areaRetangulo(altura,compr)+areaRetangulo(altura,larg)
areaBase=areaRetangulo(larg,compr)-areaCirculo(raio)

print('Serão necessário %.2f m de papel para forrar a caixa'%(areaLateral*2+areaBase*2))
