﻿# Lista 3 - exercício 4

import turtle

def desenharlinha(pat,comprimento,cor,espessura):
    pat.width(espessura)
    pat.pencolor(cor)
    pat.fd(comprimento)
    return

def desenhareixo(pat,comprimento,cor,espessura):
    pat.width(espessura)
    pat.pencolor(cor)
    pat.up()
    pat.bk(comprimento/2)
    pat.down()
    desenharlinha(pat,comprimento,cor,espessura)
    pat.up()
    pat.goto(0,0)
    pat.lt(90)
    pat.bk(comprimento/2)
    pat.down()
    desenharlinha(pat,comprimento,cor,espessura)
    return

def desenharfiguraA(pat,comprimento,cor,espessura):
    desenhareixo(pat,comprimento,cor,espessura)
    pat.up()
    pat.goto(0,0)
    pat.setheading(45)
    pat.down()
    desenhareixo(pat,comprimento/2,cor,espessura/2)
    return

def desenharfiguraB(pat,comprimento,cor,espessura):
    desenhareixo(pat,comprimento,cor,espessura)
    pat.up()
    pat.goto(0,0)
    pat.setheading(30)
    pat.down()
    desenhareixo(pat,comprimento/2,cor,espessura/2)
    
    pat.up()
    pat.goto(0,0)
    pat.setheading(60)
    pat.down()
    desenhareixo(pat,comprimento/2,cor,espessura/2)
    return

# bloco principal

pat=turtle.Turtle()

#desenharfiguraA(pat,300,'red',4)
pat.goto(0,0)
desenharfiguraB(pat,300,'red',4)
