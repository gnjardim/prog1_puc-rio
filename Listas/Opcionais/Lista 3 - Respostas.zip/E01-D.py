# Lista 3 - exercício 1.D

import turtle
import math

t=turtle.Turtle()

# seta é composta de:
# retângulo com 120(base) x 20(altura)
# triângulo equilátero com lado 100

base=120
altura=20
ladoTr=100

# recua cursor para centralizar a figura
t.up()
t.bk(150)
t.down()

#desenha retângulo
t.forward(base)
t.left(90)
t.forward(altura)
t.left(90)
t.forward(base)
t.left(90)
t.forward(altura)

# posiciona o cursor, na metade do lado direito do retângulo,
# para desenhar o triângulo

t.left(90)
t.up()
t.forward(base)
t.left(90)
t.forward(altura/2)
t.down()

#desenha triângulo
t.forward(ladoTr/2) #desenha metade do lado do triângulo
t.right(180-60)
t.forward(ladoTr)
t.right(180-60)
t.forward(ladoTr)
t.right(180-60)
t.forward(ladoTr/2) #desenha metade do lado do triângulo

