# Lista 3 - exercício 1.C

import turtle
import math

t=turtle.Turtle()

ang=45
cateto=150

t.forward(cateto)
t.left(180-ang)

hipo=cateto/math.sin(math.radians(ang))
t.forward(hipo)

t.left(180-ang)
t.forward(cateto)
