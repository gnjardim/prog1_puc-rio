﻿# Lista 3 - exercício 6

import turtle

def circulo(alex,X,Y,raio,cor):
    alex.up()
    alex.setposition(X,Y-raio)
    alex.down()
    alex.begin_fill()
    alex.fillcolor(cor)
    alex.circle(raio)
    alex.end_fill()
    return 

def quadrado(alex,X,Y,lado,cor):
    alex.up()
    alex.goto(X,Y)
    alex.left(45)
    alex.fd(lado/2*2**0.5)
    alex.setheading(0)
    alex.fillcolor(cor)
    
    alex.begin_fill()
    alex.right(90)
    alex.fd(lado)
    alex.right(90)
    alex.fd(lado)
    alex.right(90)
    alex.fd(lado)
    alex.right(90)
    alex.fd(lado)
    alex.right(90)
    
    alex.end_fill()
 
# bloco principal

alex=turtle.Turtle()
lado=70
raio=35
circulo(alex,raio,0,raio,'black')
circulo(alex,0,raio,raio,'black')
circulo(alex,0,-raio,raio,'black')
circulo(alex,-raio,0,raio,'black')
circulo(alex,0,0,lado*(2**(1/2))/2,'white')
quadrado(alex,0,0,lado,'blue')



