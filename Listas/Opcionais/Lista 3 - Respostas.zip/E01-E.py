﻿# Lista 3 - exercício 1.E

import turtle

t=turtle.Turtle()
t.up()
t.circle(100,30)
t.down()
t.circle(100,120)
t.up()
t.circle(100,240)
t.left(120)
t.down()
t.circle(-100,120)


