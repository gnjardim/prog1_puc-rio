# Lista 3 - exercício 1.A

import turtle

t=turtle.Turtle()

ang=360/5
lado=80

t.left(ang/2)
t.forward(lado)
t.left(ang)
t.forward(lado)
t.left(ang)
t.forward(lado)
t.left(ang)
t.forward(lado)
t.left(ang)
t.forward(lado)
t.left(ang)
