# Lista 3 - exercício 1.B

import turtle

t=turtle.Turtle()

ang=360/8
lado=60

t.left(ang)
t.forward(lado)
t.left(ang)
t.forward(lado)
t.left(ang)
t.forward(lado)
t.left(ang)
t.forward(lado)
t.left(ang)
t.forward(lado)
t.left(ang)
t.forward(lado)
t.left(ang)
t.forward(lado)
t.left(ang)
t.forward(lado)
t.left(ang)
