import random
def geraVotos():
    lvotos=[]
    for i in range(10): #p/um clube com 10 sócios com matr 101 a 110
        el=[101+i,random.randint(1,5)]
        lvotos.append(el)
    return lvotos
def detMaior(lUrnas):
    maior = lUrnas[0][0]
    for el in lUrnas:
        if (el[0]>maior):
            maior = el[0]
    return maior

def vencedores(lUrnas):
    maior = detMaior(lUrnas)
    lVenc=[]
    for i,el in enumerate(lUrnas):
        if el[0] == maior:
            lVenc.append(i+1)
    return lVenc



def contabilizaVotos(lUrnas):
    lVotos = geraVotos()
    print(lVotos)
    for voto in lVotos:
        ind = voto[1]-1
        lUrnas[ind][0]=(lUrnas[ind][0])+1
        lUrnas[ind][1].append(voto[0])
        
    return

def mostraVotos(lUrnas):
    for i,votos in enumerate(lUrnas):
        print('Candidato: %d - %d votos'%(i+1,votos[0]))
        print('Eleitores',votos[1])
    return

lUrnas=[]
for i in range(5):
    lUrnas.append([0,[]]) #cria lista de [contadores,lista de socios vazia]
print(lUrnas)
contabilizaVotos(lUrnas) #contabiliza os votos
mostraVotos(lUrnas) #mostra votos de cada candidato
print("Vencedores: ",vencedores(lUrnas)) #mostra lista de vencedores

