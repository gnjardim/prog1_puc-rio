import random
def geraVotos(lUrnas):
    lvotos=[]
    for i in range(10): #p/um clube com 10 sócios com matr 101 a 110
        el=[101+i,lUrnas[random.randint(0,4)][0]]
        lvotos.append(el)
    return lvotos

def detMaior(lUrnas):
    maior = lUrnas[0][1]
    for el in lUrnas:
        if (el[1]>maior):
            maior = el[1]
    return maior

def vencedores(lUrnas):
    maior = detMaior(lUrnas)
    lVenc=[]
    for i,el in enumerate(lUrnas):
        if el[1] == maior:
            lVenc.append(el[0])
    return lVenc

def busca(lUrnas,cand):
    for i,el in enumerate(lUrnas):
        if el[0] == cand:
            return i
    return 'Nok'


def contabilizaVotos(lUrnas):
    lVotos = geraVotos(lUrnas)
    print(lVotos)
    for voto in lVotos:
        ind = busca(lUrnas,voto[1])
        if ind != 'Nok':
            lUrnas[ind][1]=(lUrnas[ind][1])+1
            lUrnas[ind][2].append(voto[0])
        
    return

def mostraVotos(lUrnas):
    for i,votos in enumerate(lUrnas):
        print('Candidato: %s - %d votos'%(votos[0],votos[1]))
        print('Eleitores',votos[2])
    return

def MontaLista():
    arq = open("candidatos.txt","r")
    l=[]
    for linha in arq:
        nome=linha.strip()
        l.append([nome,0,[]])
    arq.close()
    return l

lUrnas=MontaLista()#cria lista de [nome,0,[]]
contabilizaVotos(lUrnas) #contabiliza os votos
mostraVotos(lUrnas) #mostra votos de cada candidato
print("Vencedores: ",vencedores(lUrnas)) #mostra lista de vencedores

