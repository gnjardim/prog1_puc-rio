import random
lanc=open("lancamentos.txt","w")
for i in range(480): #p/os 400 lançamentos
    lanc.write("%d\n"%random.randint(1,6))
lanc.close()
