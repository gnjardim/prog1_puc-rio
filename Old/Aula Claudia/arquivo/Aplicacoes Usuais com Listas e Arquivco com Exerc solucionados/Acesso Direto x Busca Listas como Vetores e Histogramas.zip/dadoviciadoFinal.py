def contabiliza(lOcor):
    lanc = open("lancamentos.txt","r")
    tot=0
    for linha in lanc:
        ind = int(linha.strip())-1
        lOcor[ind]=lOcor[ind]+1
        tot+=1
    lanc.close()
    return tot

def mostra (lOcor,tot):
    minimo=int(tot*0.15)
    maximo = int(tot*0.18)
    print(minimo,maximo)
    viciado = False
    for i,ocor in enumerate(lOcor):
        print('Face: %d - %d ocorrências'%(i+1,ocor))
        if ocor<minimo or ocor>maximo:
            print('Fora do aceitável')
            viciado=True
        else:
            print('Dentro do aceitável')
    return viciado





lOcor = 6*[0] #cria lista de contadores com 0
tot=contabiliza (lOcor) #contabiliza os lançamentos
viciado=mostra(lOcor,tot) #mostra ocor de cada face
if viciado:
    print("Dado viciado")

