import random
def geraVotos(lCand):
    lvotos=[]
    for i in range(10): #p/um clube com 10 sócios com matr 101 a 110
        el=[101+i,lCand[random.randint(0,4)]]
        lvotos.append(el)
    return lvotos

def detMaior(lUrnas):
    maior = lUrnas[0][0]
    for el in lUrnas:
        if (el[0]>maior):
            maior = el[0]
    return maior

def vencedores(lCand,lUrnas):
    maior = detMaior(lUrnas)
    lVenc=[]
    for i,el in enumerate(lUrnas):
        if el[0] == maior:
            lVenc.append(lCand[i])
    return lVenc



def contabilizaVotos(lCand,lUrnas):
    lVotos = geraVotos(lCand)
    print(lVotos)
    for voto in lVotos:
        if voto[1] in lCand:
            ind = lCand.index(voto[1])
            lUrnas[ind][0]=(lUrnas[ind][0])+1
            lUrnas[ind][1].append(voto[0])
        
    return

def mostraVotos(lCand,lUrnas):
    for i,votos in enumerate(lUrnas):
        print('Candidato: %s - %d votos'%(lCand[i],votos[0]))
        print('Eleitores',votos[1])
    return

def MontaListaCand():
    arq = open("candidatos.txt","r")
    l=[]
    for linha in arq:
        l.append(linha.strip())
    arq.close()
    return l

lCand=MontaListaCand()
lUrnas=[]
for i in range(5):
    lUrnas.append([0,[]]) #cria lista de [contadores,lista de socios vazia]
contabilizaVotos(lCand,lUrnas) #contabiliza os votos
mostraVotos(lCand,lUrnas) #mostra votos de cada candidato
print("Vencedores: ",vencedores(lCand,lUrnas)) #mostra lista de vencedores

